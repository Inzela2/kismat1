import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Enable CORS and logging
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))
app.use('*', logger(console.log))

// Health check
app.get('/make-server-c5325187/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// User Profile endpoints
app.post('/make-server-c5325187/profiles', async (c) => {
  try {
    const profile = await c.req.json()
    
    // Generate a unique user ID if not provided
    const userId = profile.id || `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    // Store the profile with user ID as key
    await kv.set(`profile:${userId}`, {
      ...profile,
      id: userId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
    
    console.log(`Saved profile for user: ${userId}`)
    return c.json({ success: true, userId, message: 'Profile saved successfully' })
  } catch (error) {
    console.log(`Error saving profile: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

app.get('/make-server-c5325187/profiles/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    const profile = await kv.get(`profile:${userId}`)
    
    if (!profile) {
      return c.json({ success: false, error: 'Profile not found' }, 404)
    }
    
    return c.json({ success: true, profile })
  } catch (error) {
    console.log(`Error retrieving profile: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

app.put('/make-server-c5325187/profiles/:userId', async (c) => {
  try {
    const userId = c.req.param('userId')
    const updates = await c.req.json()
    
    // Get existing profile
    const existingProfile = await kv.get(`profile:${userId}`)
    if (!existingProfile) {
      return c.json({ success: false, error: 'Profile not found' }, 404)
    }
    
    // Update profile
    const updatedProfile = {
      ...existingProfile,
      ...updates,
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`profile:${userId}`, updatedProfile)
    
    console.log(`Updated profile for user: ${userId}`)
    return c.json({ success: true, profile: updatedProfile })
  } catch (error) {
    console.log(`Error updating profile: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

// Event endpoints
app.get('/make-server-c5325187/events', async (c) => {
  try {
    // Get all events from the KV store
    const events = await kv.getByPrefix('event:')
    
    // Sort events by creation date (newest first)
    const sortedEvents = events.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    )
    
    return c.json({ success: true, events: sortedEvents })
  } catch (error) {
    console.log(`Error retrieving events: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

app.post('/make-server-c5325187/events', async (c) => {
  try {
    const eventData = await c.req.json()
    
    // Generate unique event ID
    const eventId = `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    const event = {
      id: eventId,
      ...eventData,
      participants: eventData.participants || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`event:${eventId}`, event)
    
    console.log(`Created new event: ${eventId}`)
    return c.json({ success: true, event })
  } catch (error) {
    console.log(`Error creating event: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

app.get('/make-server-c5325187/events/:eventId', async (c) => {
  try {
    const eventId = c.req.param('eventId')
    const event = await kv.get(`event:${eventId}`)
    
    if (!event) {
      return c.json({ success: false, error: 'Event not found' }, 404)
    }
    
    return c.json({ success: true, event })
  } catch (error) {
    console.log(`Error retrieving event: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

// Join event endpoint
app.post('/make-server-c5325187/events/:eventId/join', async (c) => {
  try {
    const eventId = c.req.param('eventId')
    const { userId, userName } = await c.req.json()
    
    // Get the event
    const event = await kv.get(`event:${eventId}`)
    if (!event) {
      return c.json({ success: false, error: 'Event not found' }, 404)
    }
    
    // Check if user is already joined
    if (event.participants.includes(userName)) {
      return c.json({ success: false, error: 'User already joined this event' }, 400)
    }
    
    // Check if event is full
    if (event.participants.length >= event.totalSpots) {
      return c.json({ success: false, error: 'Event is full' }, 400)
    }
    
    // Add user to event participants
    event.participants.push(userName)
    event.spotsLeft = event.totalSpots - event.participants.length
    event.updatedAt = new Date().toISOString()
    
    await kv.set(`event:${eventId}`, event)
    
    // Update user's joined events
    const profile = await kv.get(`profile:${userId}`)
    if (profile) {
      if (!profile.joinedEvents) {
        profile.joinedEvents = []
      }
      if (!profile.joinedEvents.includes(eventId)) {
        profile.joinedEvents.push(eventId)
        await kv.set(`profile:${userId}`, profile)
      }
    }
    
    console.log(`User ${userName} joined event ${eventId}`)
    return c.json({ success: true, event })
  } catch (error) {
    console.log(`Error joining event: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

// Get user's joined events
app.get('/make-server-c5325187/users/:userId/events', async (c) => {
  try {
    const userId = c.req.param('userId')
    
    // Get user profile
    const profile = await kv.get(`profile:${userId}`)
    if (!profile) {
      return c.json({ success: false, error: 'User not found' }, 404)
    }
    
    // Get all joined events
    const joinedEventIds = profile.joinedEvents || []
    const events = []
    
    for (const eventId of joinedEventIds) {
      const event = await kv.get(`event:${eventId}`)
      if (event) {
        events.push(event)
      }
    }
    
    return c.json({ success: true, events })
  } catch (error) {
    console.log(`Error retrieving user events: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

// Initialize sample events on first startup
app.post('/make-server-c5325187/init-sample-events', async (c) => {
  try {
    // Check if events already exist
    const existingEvents = await kv.getByPrefix('event:')
    if (existingEvents.length > 0) {
      return c.json({ success: true, message: 'Sample events already exist' })
    }
    
    // Create sample events
    const sampleEvents = [
      {
        id: 'bowling-friday',
        title: 'Bowling Night',
        date: 'Friday',
        time: '7:00 PM',
        location: 'Shott Mumbai',
        distance: '2.1 km away',
        spotsLeft: 2,
        totalSpots: 4,
        participants: ['Alex', 'Sarah'],
        price: 100,
        category: 'activities',
        description: 'Fun bowling session to meet new people and strike up conversations!'
      },
      {
        id: 'dinner-saturday',
        title: 'Dinner & Conversations',
        date: 'Saturday',
        time: '7:30 PM',
        location: 'Local Restaurant, Bandra',
        distance: '1.8 km away',
        spotsLeft: 4,
        totalSpots: 6,
        participants: ['Priya', 'Rohan'],
        price: 100,
        category: 'food',
        description: 'Intimate dinner setting to connect over great food and meaningful conversations.'
      },
      {
        id: 'pickleball-sunday',
        title: 'Pickleball Session',
        date: 'Sunday',
        time: '10:00 AM',
        location: 'Mumbai Sports Club',
        distance: '3.2 km away',
        spotsLeft: 4,
        totalSpots: 4,
        participants: [],
        price: 100,
        category: 'sports',
        description: 'Energetic pickleball session for beginners and experienced players alike!'
      }
    ]
    
    for (const event of sampleEvents) {
      await kv.set(`event:${event.id}`, {
        ...event,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      })
    }
    
    console.log('Sample events initialized')
    return c.json({ success: true, message: 'Sample events created' })
  } catch (error) {
    console.log(`Error initializing sample events: ${error}`)
    return c.json({ success: false, error: error.message }, 500)
  }
})

Deno.serve(app.fetch)