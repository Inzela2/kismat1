import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { UserProfile } from '../App';
import { MapPin, Clock, Users } from 'lucide-react';
import { apiClient } from '../utils/api';

interface EventsPageProps {
  profile: UserProfile;
  userId: string | null;
  onSelectEvent: (eventId: string) => void;
  onNavigate: (screen: string) => void;
}

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  distance: string;
  spotsLeft: number;
  totalSpots: number;
  participants: string[];
  price: number;
  category: string;
  description: string;
}

const sampleEvents: Event[] = [
  {
    id: 'bowling-friday',
    title: 'Bowling Night',
    date: 'Friday',
    time: '7:00 PM',
    location: 'Shott Mumbai',
    distance: '2.1 km away',
    spotsLeft: 2,
    totalSpots: 4,
    participants: ['Alex', 'Sarah'],
    price: 100,
    category: 'activities',
    description: 'Fun bowling session to meet new people and strike up conversations!'
  },
  {
    id: 'dinner-saturday',
    title: 'Dinner & Conversations',
    date: 'Saturday',
    time: '7:30 PM',
    location: 'Local Restaurant, Bandra',
    distance: '1.8 km away',
    spotsLeft: 4,
    totalSpots: 6,
    participants: ['Priya', 'Rohan'],
    price: 100,
    category: 'food',
    description: 'Intimate dinner setting to connect over great food and meaningful conversations.'
  },
  {
    id: 'pickleball-sunday',
    title: 'Pickleball Session',
    date: 'Sunday',
    time: '10:00 AM',
    location: 'Mumbai Sports Club',
    distance: '3.2 km away',
    spotsLeft: 4,
    totalSpots: 4,
    participants: [],
    price: 100,
    category: 'sports',
    description: 'Energetic pickleball session for beginners and experienced players alike!'
  }
];

export function EventsPage({ profile, userId, onSelectEvent, onNavigate }: EventsPageProps) {
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [createEventForm, setCreateEventForm] = useState({
    title: '',
    eventType: '',
    location: '',
    peopleCount: '',
    date: '',
    time: '',
    price: 100,
    description: ''
  });

  // Load events on component mount
  useEffect(() => {
    loadEvents();
  }, []);

  const loadEvents = async () => {
    setIsLoading(true);
    try {
      const result = await apiClient.getEvents();
      if (result.success && result.events) {
        setEvents(result.events);
      } else {
        console.error('Failed to load events:', result.error);
      }
    } catch (error) {
      console.error('Error loading events:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleJoinEvent = async (eventId: string) => {
    if (!userId) {
      console.error('User not logged in');
      return;
    }

    try {
      const result = await apiClient.joinEvent(eventId, userId, profile.name);
      if (result.success) {
        // Update the events list to reflect the change
        await loadEvents();
        onSelectEvent(eventId);
        onNavigate('payment');
      } else {
        alert(`Failed to join event: ${result.error}`);
      }
    } catch (error) {
      console.error('Error joining event:', error);
      alert('Failed to join event. Please try again.');
    }
  };

  const categories = [
    { id: 'all', label: 'All Events' },
    { id: 'food', label: 'Food & Drinks' },
    { id: 'activities', label: 'Activities' },
    { id: 'sports', label: 'Sports' },
    { id: 'girls-only', label: 'Girls Only' }
  ];

  const filteredEvents = selectedCategory === 'all' 
    ? events 
    : events.filter(event => event.category === selectedCategory);

  const handleCreateEventSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Map form data to event structure
      const eventData = {
        title: createEventForm.title || `${createEventForm.eventType} Event`,
        date: createEventForm.date || 'TBD',
        time: createEventForm.time || 'TBD',
        location: createEventForm.location,
        distance: 'Custom location',
        spotsLeft: parseInt(createEventForm.peopleCount.split('-')[1]) || 4,
        totalSpots: parseInt(createEventForm.peopleCount.split('-')[1]) || 4,
        participants: [profile.name], // Creator joins automatically
        price: createEventForm.price,
        category: getCategoryFromEventType(createEventForm.eventType),
        description: createEventForm.description || `Join us for ${createEventForm.eventType.toLowerCase()}!`
      };

      const result = await apiClient.createEvent(eventData);
      if (result.success) {
        await loadEvents(); // Reload events to show the new one
        setShowCreateForm(false);
        setCreateEventForm({
          title: '',
          eventType: '',
          location: '',
          peopleCount: '',
          date: '',
          time: '',
          price: 100,
          description: ''
        });
        alert('Event created successfully!');
      } else {
        alert(`Failed to create event: ${result.error}`);
      }
    } catch (error) {
      console.error('Error creating event:', error);
      alert('Failed to create event. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getCategoryFromEventType = (eventType: string): string => {
    const categoryMap: Record<string, string> = {
      'dinner': 'food',
      'drinks': 'food',
      'coffee': 'food',
      'bowling': 'activities',
      'movie': 'activities',
      'cultural': 'activities',
      'sports': 'sports',
      'other': 'activities'
    };
    return categoryMap[eventType] || 'activities';
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-black text-white px-6 py-8">
        <h1 className="text-xl mb-2" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: '500' }}>
          Hey {profile.name}!
        </h1>
        <p className="text-gray-300 text-sm" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Choose your timing and activity to get matched with like-minded people.
        </p>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Category Filter */}
        <div>
          <h2 className="text-lg mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: '500' }}>
            Choose an activity category:
          </h2>
          <div className="grid grid-cols-2 gap-3 mb-6">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className="h-auto p-4 flex flex-col items-center space-y-2"
                style={{ fontFamily: 'Poppins, sans-serif' }}
              >
                <span className="text-xs">{category.label}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Available Events */}
        <div>
          <h2 className="text-lg mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: '500' }}>
            Join Existing Activities
          </h2>
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Loading events...</p>
            </div>
          ) : filteredEvents.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No events found for this category.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEvents.map((event) => (
              <Card key={event.id} className="border-gray-200">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg" style={{ fontFamily: 'Poppins, sans-serif' }}>
                        {event.title}
                      </CardTitle>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mt-2">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{event.time} {event.date}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-4 h-4" />
                          <span>{event.distance}</span>
                        </div>
                      </div>
                    </div>
                    <Badge variant={event.spotsLeft > 0 ? "default" : "secondary"}>
                      {event.spotsLeft} spots left
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-600">{event.description}</p>
                    
                    <div className="text-sm">
                      <span className="text-gray-600">Location: </span>
                      <span>{event.location}</span>
                    </div>

                    {event.participants.length > 0 && (
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">
                          {event.participants.join(', ')} {event.participants.length === 1 ? 'is' : 'are'} joining
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-3">
                      <div className="text-sm">
                        <span className="text-gray-600">Entry fee: </span>
                        <span className="text-green-600">₹{event.price}</span>
                        <span className="text-xs text-gray-500 block">
                          (Refunded after hangout)
                        </span>
                      </div>
                      <Button
                        onClick={() => handleJoinEvent(event.id)}
                        disabled={event.spotsLeft === 0}
                        className="bg-black text-white hover:bg-gray-800"
                        style={{ fontFamily: 'Poppins, sans-serif' }}
                      >
                        {event.spotsLeft === 0 ? 'Full' : 'Join this plan'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              ))}
            </div>
          )}
        </div>

        {/* Create Your Own */}
        <Card className="border-gray-200 border-dashed">
          <CardContent className="p-6">
            {!showCreateForm ? (
              <div className="text-center">
                <h3 className="text-lg mb-2" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: '500' }}>
                  CREATE YOUR OWN PLAN
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Have something specific in mind? Create your own event and find people to join you.
                </p>
                <Button 
                  onClick={() => setShowCreateForm(true)}
                  variant="outline" 
                  className="w-full"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                >
                  Create Event
                </Button>
              </div>
            ) : (
              <form onSubmit={handleCreateEventSubmit} className="space-y-4">
                <h3 className="text-lg mb-4" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: '500' }}>
                  Create Your Event
                </h3>
                
                <div>
                  <Label htmlFor="eventType">What kind of event?</Label>
                  <Select onValueChange={(value) => setCreateEventForm(prev => ({...prev, eventType: value}))}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="Choose event type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dinner">Dinner</SelectItem>
                      <SelectItem value="drinks">Drinks</SelectItem>
                      <SelectItem value="coffee">Coffee</SelectItem>
                      <SelectItem value="bowling">Bowling</SelectItem>
                      <SelectItem value="sports">Sports Activity</SelectItem>
                      <SelectItem value="movie">Movie</SelectItem>
                      <SelectItem value="cultural">Cultural Event</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="title">Event Title (Optional)</Label>
                  <Input
                    id="title"
                    value={createEventForm.title}
                    onChange={(e) => setCreateEventForm(prev => ({...prev, title: e.target.value}))}
                    placeholder="Custom title for your event"
                    className="border-gray-300"
                  />
                </div>

                <div>
                  <Label htmlFor="location">Where?</Label>
                  <Input
                    id="location"
                    value={createEventForm.location}
                    onChange={(e) => setCreateEventForm(prev => ({...prev, location: e.target.value}))}
                    placeholder="Enter location or area"
                    className="border-gray-300"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={createEventForm.date}
                      onChange={(e) => setCreateEventForm(prev => ({...prev, date: e.target.value}))}
                      className="border-gray-300"
                    />
                  </div>
                  <div>
                    <Label htmlFor="time">Time</Label>
                    <Input
                      id="time"
                      type="time"
                      value={createEventForm.time}
                      onChange={(e) => setCreateEventForm(prev => ({...prev, time: e.target.value}))}
                      className="border-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Input
                    id="description"
                    value={createEventForm.description}
                    onChange={(e) => setCreateEventForm(prev => ({...prev, description: e.target.value}))}
                    placeholder="Tell people what to expect..."
                    className="border-gray-300"
                  />
                </div>

                <div>
                  <Label htmlFor="peopleCount">Preferred number of people?</Label>
                  <Select onValueChange={(value) => setCreateEventForm(prev => ({...prev, peopleCount: value}))}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="Choose group size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2-3">2-3 people</SelectItem>
                      <SelectItem value="4-5">4-5 people</SelectItem>
                      <SelectItem value="6-8">6-8 people</SelectItem>
                      <SelectItem value="8+">8+ people</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    variant="outline"
                    className="flex-1"
                    disabled={isLoading}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-black text-white hover:bg-gray-800"
                    disabled={isLoading || !createEventForm.eventType || !createEventForm.location}
                  >
                    {isLoading ? 'Creating...' : 'Create Event'}
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
          <div className="max-w-md mx-auto">
            <Button
              onClick={() => onNavigate('dashboard')}
              variant="outline"
              className="w-full"
              style={{ fontFamily: 'Poppins, sans-serif' }}
            >
              My Dashboard
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}