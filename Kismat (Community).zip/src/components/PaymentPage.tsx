import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle, CreditCard, Shield, ArrowLeft } from 'lucide-react';

interface PaymentPageProps {
  eventId: string | null;
  onNavigate: (screen: string) => void;
}

export function PaymentPage({ eventId, onNavigate }: PaymentPageProps) {
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);

  const handlePayment = async () => {
    setPaymentProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setPaymentProcessing(false);
      setPaymentComplete(true);
    }, 2000);
  };

  const handleContinue = () => {
    onNavigate('chat');
  };

  if (paymentComplete) {
    return (
      <div className="min-h-screen bg-white px-6 py-8 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <Card className="border-gray-200">
            <CardHeader>
              <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-xl text-green-600">Payment Successful!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-green-800">
                  <strong>₹100 paid successfully</strong>
                </p>
                <p className="text-xs text-green-600 mt-1">
                  This amount will be refunded after your hangout when you upload a selfie
                </p>
              </div>
              
              <div className="space-y-2 text-sm">
                <p><strong>What's next?</strong></p>
                <ul className="text-gray-600 space-y-1">
                  <li>• Join the event chat room</li>
                  <li>• Connect with other participants</li>
                  <li>• Get event details and updates</li>
                  <li>• Have fun at the event!</li>
                </ul>
              </div>

              <Button
                onClick={handleContinue}
                className="w-full bg-black text-white hover:bg-gray-800 py-3"
              >
                Join Chat Room
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-black text-white px-6 py-4 flex items-center">
        <Button
          onClick={() => onNavigate('events')}
          variant="ghost"
          size="sm"
          className="text-white hover:bg-gray-800 mr-4"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-lg">Complete Payment</h1>
      </div>

      <div className="px-6 py-8">
        <div className="max-w-md mx-auto space-y-6">
          {/* Security Notice */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4 flex items-start space-x-3">
              <Shield className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div className="text-sm">
                <p className="text-blue-800 mb-1">
                  <strong>Refundable Security Deposit</strong>
                </p>
                <p className="text-blue-700">
                  This ₹100 is a refundable deposit. You'll get it back after attending the event and uploading a verification selfie.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Payment Details */}
          <Card className="border-gray-200">
            <CardHeader>
              <CardTitle className="text-lg flex items-center space-x-2">
                <CreditCard className="w-5 h-5" />
                <span>Payment Details</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Event booking fee</span>
                <span>₹100</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Processing fee</span>
                <span>₹0</span>
              </div>
              <div className="flex justify-between py-2 border-b-2 border-gray-300">
                <span className="text-lg">Total</span>
                <span className="text-lg">₹100</span>
              </div>
              
              <div className="bg-yellow-50 p-3 rounded-lg">
                <p className="text-xs text-yellow-800">
                  <strong>Refund Policy:</strong> The full amount will be refunded within 24 hours after you upload a verification selfie from the event.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card className="border-gray-200">
            <CardHeader>
              <CardTitle className="text-lg">Payment Method</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="border border-blue-200 bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                      <span className="text-white text-xs">FP</span>
                    </div>
                    <div>
                      <p className="text-sm">FamPay Wallet</p>
                      <p className="text-xs text-gray-600">Secure digital payment</p>
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-gray-500">
                  Other payment methods (Razorpay, UPI, Cards) will be available soon.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Terms */}
          <div className="text-xs text-gray-500 space-y-2">
            <p>
              By proceeding with payment, you agree to our Terms of Service and Privacy Policy.
            </p>
            <p>
              You must attend the event and follow community guidelines to be eligible for the refund.
            </p>
          </div>

          {/* Payment Button */}
          <Button
            onClick={handlePayment}
            disabled={paymentProcessing}
            className="w-full bg-black text-white hover:bg-gray-800 py-4 text-lg"
          >
            {paymentProcessing ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Processing...</span>
              </div>
            ) : (
              'Pay ₹100'
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}