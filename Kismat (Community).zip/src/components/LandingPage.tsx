import React from 'react';
import { Button } from './ui/button';
import kismatLogo from 'figma:asset/277639fb0dbecc138141412528c84c80394203c1.png';

interface LandingPageProps {
  onNavigate: (screen: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-6 py-8">
      {/* Logo */}
      <div className="mb-12">
        <img 
          src={kismatLogo} 
          alt="Kismat Logo" 
          className="w-64 h-auto max-w-full"
        />
      </div>

      {/* Welcome Message */}
      <div className="text-center mb-12 max-w-sm">
        <h1 className="text-xl mb-4 text-black">
          Meet your new favorite people through shared experiences in your city.
        </h1>
        <p className="text-gray-600">
          Find My People
        </p>
      </div>

      {/* Get Started Button */}
      <div className="w-full max-w-sm space-y-4">
        <Button
          onClick={() => onNavigate('profile')}
          className="w-full bg-black text-white hover:bg-gray-800 py-3 rounded-lg"
        >
          Get Started
        </Button>
        
        {/* Login/Sign Up Options */}
        <div className="text-center text-sm text-gray-600">
          <span>Already have an account? </span>
          <button className="text-black underline">
            Log in
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-16 text-xs text-gray-400 text-center">
        Connect. Experience. Belong.
      </div>
    </div>
  );
}