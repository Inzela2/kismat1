import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { UserProfile } from '../App';
import starIcon from 'figma:asset/7b020bf7102ddbbffe9451ec48111cb6db1aa563.png';

interface ProfileCreationProps {
  profile: UserProfile;
  onUpdateProfile: (updates: Partial<UserProfile>) => void;
  onNavigate: (screen: string) => void;
}

export function ProfileCreation({ profile, onUpdateProfile, onNavigate }: ProfileCreationProps) {
  const [formData, setFormData] = useState({
    name: profile.name,
    age: profile.age,
    gender: profile.gender,
    pronouns: profile.pronouns,
    studentOrProfessional: '',
    workStudy: profile.workStudy,
    apartment: profile.location.apartment,
    locality: profile.location.locality,
    suburb: profile.location.suburb,
    city: profile.location.city
  });

  const [showVerification, setShowVerification] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const updatedProfile = {
      ...formData,
      location: {
        apartment: formData.apartment,
        locality: formData.locality,
        suburb: formData.suburb,
        city: formData.city
      }
    };
    
    onUpdateProfile(updatedProfile);
    onNavigate('personality');
  };

  const handlePhotoVerification = () => {
    setShowVerification(true);
    // Simulate verification process
    setTimeout(() => {
      setShowVerification(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-white px-6 py-8">
      {/* Floating Ball Decoration */}
      <div className="fixed top-8 right-8 w-12 h-12 opacity-20">
        <img src={starIcon} alt="" className="w-full h-full transform rotate-12" />
      </div>
      <div className="fixed bottom-20 left-6 w-8 h-8 opacity-15">
        <img src={starIcon} alt="" className="w-full h-full transform -rotate-45" />
      </div>

      <div className="max-w-md mx-auto">
        <h1 className="text-2xl mb-8 text-center text-black">Create Your Profile</h1>

        {/* Photo Upload Section */}
        <Card className="mb-6 border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg">Photo & Verification</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-gray-100 rounded-full mx-auto flex items-center justify-center">
                <span className="text-gray-400">📷</span>
              </div>
              {!showVerification ? (
                <Button
                  onClick={handlePhotoVerification}
                  variant="outline"
                  className="w-full"
                >
                  Upload Photo & Verify
                </Button>
              ) : (
                <div className="text-green-600 space-y-2">
                  <div className="text-sm">✓ Face verification complete!</div>
                  <div className="text-xs text-gray-500">You can proceed to the next step</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Personal Details Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                required
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                required
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="gender">Gender</Label>
              <Select onValueChange={(value) => handleInputChange('gender', value)}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="non-binary">Non-binary</SelectItem>
                  <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="pronouns">Pronouns</Label>
              <Input
                id="pronouns"
                value={formData.pronouns}
                onChange={(e) => handleInputChange('pronouns', e.target.value)}
                placeholder="e.g., they/them, she/her, he/him"
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="studentOrProfessional">Are you a student or professional?</Label>
              <Select onValueChange={(value) => handleInputChange('studentOrProfessional', value)}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder="Select one" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="professional">Professional</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.studentOrProfessional && (
              <div>
                <Label htmlFor="workStudy">
                  {formData.studentOrProfessional === 'student' ? 'Where do you study?' : 'Where do you work and what do you do?'}
                </Label>
                <Input
                  id="workStudy"
                  value={formData.workStudy}
                  onChange={(e) => handleInputChange('workStudy', e.target.value)}
                  placeholder={formData.studentOrProfessional === 'student' ? 'University/College name' : 'Company name and your role'}
                  required
                  className="border-gray-300"
                />
              </div>
            )}
          </div>

          {/* Location Details */}
          <div className="space-y-4">
            <h3 className="text-lg">Location</h3>
            
            <div>
              <Label htmlFor="apartment">Apartment/Building Number</Label>
              <Input
                id="apartment"
                value={formData.apartment}
                onChange={(e) => handleInputChange('apartment', e.target.value)}
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="locality">Locality</Label>
              <Input
                id="locality"
                value={formData.locality}
                onChange={(e) => handleInputChange('locality', e.target.value)}
                required
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="suburb">Suburb</Label>
              <Input
                id="suburb"
                value={formData.suburb}
                onChange={(e) => handleInputChange('suburb', e.target.value)}
                required
                className="border-gray-300"
              />
            </div>

            <div>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => handleInputChange('city', e.target.value)}
                required
                className="border-gray-300"
              />
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-black text-white hover:bg-gray-800 py-3"
          >
            Continue to Personality Questions
          </Button>
        </form>
      </div>
    </div>
  );
}