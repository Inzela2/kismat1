import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Send, ArrowLeft, Users, MapPin, Clock } from 'lucide-react';
import { UserProfile } from '../App';

interface ChatRoomProps {
  eventId: string | null;
  profile: UserProfile;
  onNavigate: (screen: string) => void;
}

interface Message {
  id: string;
  sender: string;
  message: string;
  timestamp: Date;
  isSystem?: boolean;
}

interface Participant {
  name: string;
  joinedAt: Date;
  avatar?: string;
}

const eventDetails = {
  'bowling-friday': {
    title: 'Bowling Night',
    date: 'Friday',
    time: '7:00 PM',
    location: 'Shott Mumbai',
    participants: ['Alex', 'Sarah', 'You']
  },
  'dinner-saturday': {
    title: 'Dinner & Conversations',
    date: 'Saturday', 
    time: '7:30 PM',
    location: 'Local Restaurant, Bandra',
    participants: ['Priya', 'Rohan', 'You']
  },
  'pickleball-sunday': {
    title: 'Pickleball Session',
    date: 'Sunday',
    time: '10:00 AM', 
    location: 'Mumbai Sports Club',
    participants: ['You']
  }
};

export function ChatRoom({ eventId, profile, onNavigate }: ChatRoomProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'System',
      message: `Welcome to the event chat! ${profile.name} has joined the group.`,
      timestamp: new Date(),
      isSystem: true
    },
    {
      id: '2',
      sender: 'Alex',
      message: 'Hey everyone! Really excited for this event 🎳',
      timestamp: new Date(Date.now() - 5 * 60000)
    },
    {
      id: '3',
      sender: 'Sarah',
      message: 'Same here! Has anyone been to Shott before?',
      timestamp: new Date(Date.now() - 3 * 60000)
    }
  ]);
  
  const [newMessage, setNewMessage] = useState('');
  const [participants] = useState<Participant[]>([
    { name: 'Alex', joinedAt: new Date(Date.now() - 30 * 60000) },
    { name: 'Sarah', joinedAt: new Date(Date.now() - 15 * 60000) },
    { name: profile.name, joinedAt: new Date() }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const event = eventId ? eventDetails[eventId as keyof typeof eventDetails] : null;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Date.now().toString(),
      sender: profile.name,
      message: newMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simulate other participants responding
    setTimeout(() => {
      const responses = [
        'Sounds great!',
        'Looking forward to it!',
        'Me too! 😊',
        'Can\'t wait to meet everyone',
        'This is going to be fun!'
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      const otherParticipants = participants.filter(p => p.name !== profile.name);
      const randomParticipant = otherParticipants[Math.floor(Math.random() * otherParticipants.length)];
      
      if (randomParticipant) {
        const responseMessage: Message = {
          id: (Date.now() + 1).toString(),
          sender: randomParticipant.name,
          message: randomResponse,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, responseMessage]);
      }
    }, 1000 + Math.random() * 3000);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  if (!event || !eventId) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center px-6">
        <div className="text-center">
          <p className="text-lg mb-4">Event not found</p>
          <Button onClick={() => onNavigate('events')} className="bg-black text-white hover:bg-gray-800">
            Back to Events
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-black text-white px-4 py-3 flex items-center space-x-3">
        <Button
          onClick={() => onNavigate('events')}
          variant="ghost"
          size="sm"
          className="text-white hover:bg-gray-800"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg">{event.title}</h1>
          <div className="flex items-center space-x-4 text-xs text-gray-300">
            <div className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>{event.time} {event.date}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="w-3 h-3" />
              <span>{participants.length} members</span>
            </div>
          </div>
        </div>
      </div>

      {/* Event Info Card */}
      <div className="p-4 border-b border-gray-200">
        <Card className="border-gray-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center text-white">
                🎳
              </div>
              <div className="flex-1">
                <h3 className="text-sm">{event.title}</h3>
                <div className="flex items-center space-x-2 text-xs text-gray-600 mt-1">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{event.time} {event.date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span>{event.location}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-2">
                  {participants.map((participant, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {participant.name}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.sender === profile.name ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs lg:max-w-md ${message.isSystem ? 'w-full' : ''}`}>
              {message.isSystem ? (
                <div className="bg-gray-100 rounded-lg p-3 text-center">
                  <p className="text-xs text-gray-600">{message.message}</p>
                  <p className="text-xs text-gray-400 mt-1">{formatTime(message.timestamp)}</p>
                </div>
              ) : (
                <div className={`rounded-lg p-3 ${
                  message.sender === profile.name 
                    ? 'bg-black text-white ml-auto' 
                    : 'bg-gray-100 text-black'
                }`}>
                  {message.sender !== profile.name && (
                    <p className="text-xs opacity-70 mb-1">{message.sender}</p>
                  )}
                  <p className="text-sm">{message.message}</p>
                  <p className={`text-xs mt-1 ${
                    message.sender === profile.name ? 'text-gray-300' : 'text-gray-500'
                  }`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="border-t border-gray-200 p-4">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 border-gray-300"
          />
          <Button
            type="submit"
            size="sm"
            className="bg-black text-white hover:bg-gray-800"
            disabled={!newMessage.trim()}
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>

      {/* Quick Actions */}
      <div className="border-t border-gray-200 p-4 bg-gray-50">
        <div className="flex space-x-2">
          <Button
            onClick={() => onNavigate('dashboard')}
            variant="outline"
            size="sm"
            className="flex-1"
          >
            My Dashboard
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
          >
            Event Details
          </Button>
        </div>
      </div>
    </div>
  );
}