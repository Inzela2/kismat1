import React, { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { ProfileCreation } from './components/ProfileCreation';
import { PersonalityQuestions } from './components/PersonalityQuestions';
import { ConfirmationPage } from './components/ConfirmationPage';
import { EventsPage } from './components/EventsPage';
import { PaymentPage } from './components/PaymentPage';
import { ChatRoom } from './components/ChatRoom';
import { UserDashboard } from './components/UserDashboard';
import { apiClient } from './utils/api';

export type Screen = 
  | 'landing'
  | 'profile'
  | 'personality'
  | 'confirmation'
  | 'events'
  | 'payment'
  | 'chat'
  | 'dashboard';

export type UserProfile = {
  id?: string;
  name: string;
  age: string;
  gender: string;
  pronouns: string;
  workStudy: string;
  location: {
    apartment: string;
    locality: string;
    suburb: string;
    city: string;
  };
  personalityAnswers: Record<string, any>;
  joinedEvents: string[];
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: '',
    age: '',
    gender: '',
    pronouns: '',
    workStudy: '',
    location: {
      apartment: '',
      locality: '',
      suburb: '',
      city: ''
    },
    personalityAnswers: {},
    joinedEvents: []
  });
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Initialize sample events and load user session on app start
  useEffect(() => {
    const initializeApp = async () => {
      // Initialize sample events
      await apiClient.initSampleEvents();
      
      // Check if user has a saved session
      const savedUserId = localStorage.getItem('userId');
      if (savedUserId) {
        const result = await apiClient.getProfile(savedUserId);
        if (result.success && result.profile) {
          setUserId(savedUserId);
          setUserProfile(result.profile);
          setCurrentScreen('events'); // Skip to events if user already has profile
        }
      }
    };
    
    initializeApp();
  }, []);

  const navigateTo = (screen: Screen) => {
    setCurrentScreen(screen);
    // Handle chat navigation with stored event
    if (screen === 'chat' && !selectedEvent) {
      const storedEvent = window.sessionStorage.getItem('selectedEvent');
      if (storedEvent) {
        setSelectedEvent(storedEvent);
      }
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    setUserProfile(prev => ({ ...prev, ...updates }));
    
    // If user ID exists, update the profile in backend
    if (userId) {
      await apiClient.updateProfile(userId, updates);
    }
  };

  const saveProfileToBackend = async () => {
    setIsLoading(true);
    try {
      const result = await apiClient.saveProfile(userProfile);
      if (result.success && result.userId) {
        setUserId(result.userId);
        setUserProfile(prev => ({ ...prev, id: result.userId }));
        localStorage.setItem('userId', result.userId);
        console.log('Profile saved successfully');
      } else {
        console.error('Failed to save profile:', result.error);
      }
    } catch (error) {
      console.error('Error saving profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const logoutUser = () => {
    localStorage.removeItem('userId');
    setUserId(null);
    setUserProfile({
      name: '',
      age: '',
      gender: '',
      pronouns: '',
      workStudy: '',
      location: {
        apartment: '',
        locality: '',
        suburb: '',
        city: ''
      },
      personalityAnswers: {},
      joinedEvents: []
    });
    setCurrentScreen('landing');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'landing':
        return <LandingPage onNavigate={navigateTo} />;
      case 'profile':
        return (
          <ProfileCreation
            profile={userProfile}
            onUpdateProfile={updateProfile}
            onNavigate={navigateTo}
          />
        );
      case 'personality':
        return (
          <PersonalityQuestions
            profile={userProfile}
            onUpdateProfile={updateProfile}
            onNavigate={navigateTo}
          />
        );
      case 'confirmation':
        return (
          <ConfirmationPage
            profile={userProfile}
            onNavigate={navigateTo}
            onSaveProfile={saveProfileToBackend}
            isLoading={isLoading}
          />
        );
      case 'events':
        return (
          <EventsPage
            profile={userProfile}
            userId={userId}
            onSelectEvent={setSelectedEvent}
            onNavigate={navigateTo}
          />
        );
      case 'payment':
        return (
          <PaymentPage
            eventId={selectedEvent}
            onNavigate={navigateTo}
          />
        );
      case 'chat':
        return (
          <ChatRoom
            eventId={selectedEvent}
            profile={userProfile}
            onNavigate={navigateTo}
          />
        );
      case 'dashboard':
        return (
          <UserDashboard
            profile={userProfile}
            userId={userId}
            onNavigate={navigateTo}
            onLogout={logoutUser}
          />
        );
      default:
        return <LandingPage onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen bg-white text-black" style={{ fontFamily: 'Poppins, sans-serif' }}>
      {renderScreen()}
    </div>
  );
}