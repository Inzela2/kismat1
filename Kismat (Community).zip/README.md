
  # Kismat (Community)

  This is a code bundle for Kismat (Community). The original project is available at https://www.figma.com/design/9qNIaN2xTbvOz8D4pvF1X1/Kismat--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  